﻿--- COMPILATION AND RUN TIME INSTRUCTION ---

•Move to the location in which you have saved the code file by using the cd command in the terminal.  For example, if you have saved the file in your Desktop,then change the working directory to Desktop by the following -->   'cd Desktop' without '' in the terminal.  Please note that this is just an example, you will have to move to your directory in which you have saved, if it is Desktop then the above example is sufficient.

•Compile the code using the command-->        g++ -pthread -o Problem4 Problem4.cpp

•To run it, use the command-->                ./Problem4

•The program requires number of customers to be provided as input.  As mentioned by sir, the number of customers must be less than or equal to 24.

•After providing the input, press the ENTER button and the program should start running
