#include <iostream>
#include <pthread.h>
#include <chrono>
#include <algorithm>
#include <sys/time.h>
#include <cstring>
#define ll unsigned long long int 
using namespace std;
using namespace std::chrono;
// maximum size of matrix 
#define D 4096

// maximum number of threads 
int MAX_THREAD;  


int BLOCK_SIZE;

//D is the dimension
ll a[D][D], b[D][D],c[D][D],d[D][D],e[D][D];
int steps = 0; 




void sequential()
{
	for(ll i=0;i<D;i++)
	{
		for(ll j=0;j<D;j++)
		{
			d[i][j]=0;

			for(ll k=0;k<D;k++)
				d[i][j]+=(a[i][k]*b[k][j]);
		}

	}

}


void swb()  //sequential with blocking
{
	int i, j, k, u, v;
 double sum;
 int lim = BLOCK_SIZE * (D/BLOCK_SIZE); 

 
 for (i = 0; i < D; i++)
 		for (j = 0; j < D; j++)
 			e[i][j] = 0.0;
 

 for (u = 0; u < lim; u += BLOCK_SIZE) 
 {
 	for (v = 0; v < lim; v += BLOCK_SIZE) 
 	{
 		for (i = 0; i < D ; i++)
 		{
 			for (j = v; j < v + BLOCK_SIZE; j++) 
 			{
 				sum = e[i][j];
 
 				for (k = u; k < u + BLOCK_SIZE; k++) 
 				{
 					sum += a[i][k]*b[k][j];
 				}

				e[i][j] = sum;
 			}
		 }
	 }
 }
}







void* multi(void* arg) 
{ 
	int value = steps++; 

				
 int i, j, k, u, v;
 double sum;
 int lim = BLOCK_SIZE * (D/BLOCK_SIZE); 

 

 for (u = 0; u < lim; u += BLOCK_SIZE) 
 {
 	for (v = 0; v < lim; v += BLOCK_SIZE) 
 	{
 		for (i = value * D / MAX_THREAD; i < (value + 1) * D / MAX_THREAD; i++)
 		{
 			for (j = v; j < v + BLOCK_SIZE; j++) 
 			{
 				sum = c[i][j];
 
 				for (k = u; k < u + BLOCK_SIZE; k++) 
 				{
 					sum += a[i][k]*b[k][j];
 				}

				c[i][j] = sum;
 			}
		 }
	 }
 }
 

				
				
	return NULL;
} 





int main()
{
   
   cout<<"Enter the block size: ";
   cin>>BLOCK_SIZE;
   cout<<"Enter the number of threads: ";
   cin>>MAX_THREAD; 
   ll i,j,k;
   
   
   
   for(ll i=0;i<D;i++)
   {
   	for(ll j=0;j<D;j++)
   	{
   	  a[i][j]=1;
	  b[i][j]=1;	
	}
   }
   



//sequential

auto startTime2= high_resolution_clock::now();
sequential();
auto stopTime2 = high_resolution_clock::now();

auto duration2 = duration_cast<microseconds>(stopTime2 - startTime2);
    
   cout << "Sec in sequential: " << duration2.count()/1000000 << endl;




//sequential with blocking

auto startTime1 = high_resolution_clock::now();
swb();
auto stopTime1 = high_resolution_clock::now();

auto duration1 = duration_cast<microseconds>(stopTime1 - startTime1);
    
cout << "Sec in sequential with blocking: " << duration1.count()/1000000 << endl;




  // declaring four threads 
	pthread_t threads[MAX_THREAD]; 

	// Creating four threads, each evaluating its own part 
	for (int i = 0; i < MAX_THREAD; i++) { 
		int* p; 
		pthread_create(&threads[i], NULL, multi, (void*)(p)); 
	} 


 auto startTime = high_resolution_clock::now();
   

	// joining and waiting for all threads to complete 
	for (int i = 0; i < MAX_THREAD; i++) 
		pthread_join(threads[i], NULL);	 
   
    
  auto stopTime = high_resolution_clock::now(); 
  
    auto duration = duration_cast<microseconds>(stopTime - startTime);
    
   cout << "Sec in parallel: " << duration.count()/1000000 << endl;
   
   
   

//for printing (if u want to)

/*
printf("the matrix multiplication is:\n");
for(i=0;i<D;i++)
{for(j=0;j<D;j++)
{printf("\t%d",e[i][j]);
}
printf("\n");}
*/   
   
}
