#include <iostream>
#include <pthread.h>
#include <chrono>
#include <algorithm>
#include <sys/time.h>
#include <cstring>
#define ll unsigned long long int 
using namespace std;
using namespace std::chrono;
// dimension of the matrix 
#define D 4096


ll a[D][D], b[D][D],c[D][D],d[D][D];
int steps = 0; 

ll MAX_THREAD; // the maximum number of threads, ipnut will be from user


void sequential()
{
	for(ll i=0;i<D;i++)
	{
		for(ll j=0;j<D;j++)
		{
			d[i][j]=0;
			for (int k = 0; k < D; k+=2)
			{ 
			 //d[i][j] += a[i][k] * b[k][j];
			 
			 	//unrolling factor 10
			 	
				d[i][j] += a[i][k+0] * b[k+0][j];
				d[i][j] += a[i][k+1] * b[k+1][j];
				/*d[i][j] += a[i][k+2] * b[k+2][j];
				d[i][j] += a[i][k+3] * b[k+3][j];
				d[i][j] += a[i][k+4] * b[k+4][j];
				d[i][j] += a[i][k+5] * b[k+5][j];
				d[i][j] += a[i][k+6] * b[k+6][j];
				d[i][j] += a[i][k+7] * b[k+7][j];
				d[i][j] += a[i][k+8] * b[k+8][j];
				d[i][j] += a[i][k+9] * b[k+9][j];*/
			}
		}

	}

}


void* matmul(void* argument) 
{ 
	int value = steps++; 

	// Each thread computes 1/tth of matrix multiplication 
	for (int i = value * D / MAX_THREAD; i < (value + 1) * D / MAX_THREAD; i++) 
		for (int j = 0; j < D; j++) 
			for (int k = 0; k < D; k+=10)
			{ 
			 //c[i][j] += a[i][k] * b[k][j];
			  	
			  	//unrolling factor q0
			 
				c[i][j] += a[i][k+0] * b[k+0][j];
				c[i][j] += a[i][k+1] * b[k+1][j];
				c[i][j] += a[i][k+2] * b[k+2][j];
				c[i][j] += a[i][k+3] * b[k+3][j];
				c[i][j] += a[i][k+4] * b[k+4][j];
				c[i][j] += a[i][k+5] * b[k+5][j];
				c[i][j] += a[i][k+6] * b[k+6][j];
				c[i][j] += a[i][k+7] * b[k+7][j];
				c[i][j] += a[i][k+8] * b[k+8][j];
				c[i][j] += a[i][k+9] * b[k+9][j];
				
				
			}	
				
				
	return NULL;
} 





int main()
{
   ll i,j,k;
   
     cout<<"Enter the number of threads: ";
     cin>>MAX_THREAD;
   
   for(ll i=0;i<D;i++)
   {
   	for(ll j=0;j<D;j++)
   	{
   	  a[i][j]=1;
	  b[i][j]=1;	
	}
   }
   



//sequential


auto startTime1 = high_resolution_clock::now();
sequential();
auto stopTime1 = high_resolution_clock::now();

auto duration1 = duration_cast<microseconds>(stopTime1 - startTime1);
    
   cout << "Sec in sequential using unrolling : " << duration1.count()/1000000 << endl;
   
   

  // declaring four threads 
	pthread_t threads[MAX_THREAD]; 

	// Creating four threads, each evaluating its own part 
	for (int i = 0; i < MAX_THREAD; i++) { 
		int* p; 
		pthread_create(&threads[i], NULL, matmul, (void*)(p)); 
	} 


 auto startTime = high_resolution_clock::now();
   

	// joining and waiting for all threads to complete 
	for (int i = 0; i < MAX_THREAD; i++) 
		pthread_join(threads[i], NULL);	 
   
    
  auto stopTime = high_resolution_clock::now(); 
  
    auto duration = duration_cast<microseconds>(stopTime - startTime);
    
   cout << "Sec in parallel: " << duration.count()/1000000 << endl;
   
   
   

//for printing (if u want to)

/*
printf("the matrix multiplication is:\n");
for(i=0;i<D;i++)
{for(j=0;j<D;j++)
{printf("\t%d",c[i][j]);
}
printf("\n");}
  */ 
   
}
