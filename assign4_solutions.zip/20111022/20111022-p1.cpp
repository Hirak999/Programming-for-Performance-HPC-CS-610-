

#include <cassert>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <omp.h>
#include <tbb/tbb.h>

#define N 50

using std::cout;
using std::endl;
using std::chrono::duration_cast;
using HR = std::chrono::high_resolution_clock;
using HRTimer = HR::time_point;
using std::chrono::microseconds;
using namespace tbb;

// Serial Fibonacci
long ser_fib(int n) {
  if (n == 0 || n == 1) {
    return (n);
  }
  return ser_fib(n - 1) + ser_fib(n - 2);
}



long omp_fib_v1(int n) {
  
  if (n < 2) return n;

  
 long long int x, y;
#pragma omp task shared(x) 
{
x = omp_fib_v1(n - 1);
}
#pragma omp task shared(y) 
{
y = omp_fib_v1(n - 2);
}
#pragma omp taskwait
return x+y;
  
  
}

long omp_fib_v2(int n) {

  if (n < 2) return n;
  
  if (n <= 30)   //n less than 20 or 30 is giving really good performance
return ser_fib(n);
  
 long long int x, y;
#pragma omp task shared(x) firstprivate(n)
{
x = omp_fib_v2(n - 1);
}
#pragma omp task shared(y) firstprivate(n)
{
y = omp_fib_v2(n - 2);
}
#pragma omp taskwait
return x+y;
  

}


//Task creation
class FibTask: public tbb::task {
public:
    const long n;
    long* const sum;
    FibTask( long n_, long* sum_ ) :
        n(n_), sum(sum_)
    {}
    tbb::task* execute() {      // Overrides virtual function task::execute
        if( n<= 20) {
            *sum = ser_fib(n);
        } else {
            long x, y;
            FibTask& a = *new( allocate_child() ) FibTask(n-1,&x);
            FibTask& b = *new( allocate_child() ) FibTask(n-2,&y);
            // Set ref_count to 'two children plus one for the wait".
            set_ref_count(3);
            // Start b running.
            spawn( b );
            // Start a running and wait for all children (a and b).
            spawn_and_wait_for_all(a);
            // Do the sum
            *sum = x+y;
        }
        return NULL;
    }
};


long tbb_fib_blocking(int n) {
  
  long sum;
    FibTask& a = *new(tbb::task::allocate_root()) FibTask(n,&sum);
    tbb::task::spawn_root_and_wait(a);
    return sum;
  
}


// structure for continuation 
struct FibC: public task {
    long* const sum;
    long x, y;
    FibC( long* sum_ ) : sum(sum_) {}
    task* execute() {
        *sum = x+y;
        return NULL;
    }
};
// structure for continuation passing style
 struct FibTaskC: public task {
    const long n;
    long* const sum;
    FibTaskC( long n_, long* sum_ ) :
        n(n_), sum(sum_)
    {}
    task* execute() {
        if( n<= 20 ) {
            *sum = ser_fib(n);
            return NULL;
        } else {

            FibC& c = *new( allocate_continuation() ) FibC(sum);
            FibTaskC& a = *new( c.allocate_child() ) FibTaskC(n-2,&c.x);
            FibTaskC& b = *new( c.allocate_child() ) FibTaskC(n-1,&c.y);
            c.set_ref_count(2);
            spawn( b );
            spawn( a );

            return NULL;
        }
    }
};


long tbb_fib_cps(int n) {
  
   long sum;
    FibTaskC& a = *new(task::allocate_root()) FibTaskC(n,&sum);
    task::spawn_root_and_wait(a);
    return sum;
  
}



int main(int argc, char** argv) {
  cout << std::fixed << std::setprecision(5);

  HRTimer start = HR::now();
  long s_fib = ser_fib(N);
  HRTimer end = HR::now();
  auto duration = duration_cast<microseconds>(end - start).count();
  cout << "Serial time: " << duration << " microseconds" << endl;




long omp_v1;
 start = HR::now();
 
#pragma omp parallel
{
	#pragma omp single
	{
		omp_v1 = omp_fib_v1(N);
	}
}
  
  
  end = HR::now();
  assert(s_fib == omp_v1);
  duration = duration_cast<microseconds>(end - start).count();
  cout << "OMP v1 time: " << duration << " microseconds" << endl;



long omp_v2;

 start = HR::now();
 
#pragma omp parallel
{
	#pragma omp single
	{
		omp_v2 = omp_fib_v2(N);
	}
}
  
  end = HR::now();
  assert(s_fib == omp_v2);
  duration = duration_cast<microseconds>(end - start).count();
  cout << "OMP v2 time: " << duration << " microseconds" << endl;

  start = HR::now();
  long blocking_fib = tbb_fib_blocking(N);
  end = HR::now();
  assert(s_fib == blocking_fib);
  duration = duration_cast<microseconds>(end - start).count();
  cout << "TBB (blocking) time: " << duration << " microseconds" << endl;

  start = HR::now();
  long cps_fib = tbb_fib_cps(N);
  end = HR::now();
  assert(s_fib == cps_fib);
  duration = duration_cast<microseconds>(end - start).count();
  cout << "TBB (cps) time: " << duration << " microseconds" << endl;

  return EXIT_SUCCESS;
}
