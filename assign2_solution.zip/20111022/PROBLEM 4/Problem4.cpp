#include<iostream>
#include<pthread.h>
#include<mutex>
#include<chrono>
#include<stdlib.h>
#include <unistd.h>
#include<mutex>
#include<time.h>
#define MAX_THREAD 2
using namespace std;

int n; //number of customers

int c[24]={0}; //array of customers to which token will be assigned

int a[24]={0}; //queue of customer after they get the tocken

int w[16]={0}; //the shared array in which the customer writes his/her tocken for 8 times 

int counter=0; 

mutex m,m1,m2; //mutex 


//This function is inserting the customers to the queue 'a', each of the customer is a thread and can enter the queue independently of the tocken numbers

void* fifo(void *arg)
   { 

	int p = *((int *) arg);

        m.lock();
	
	a[counter]= c[p];
	
	counter++;
	
	m.unlock(); 
	 	
	return NULL;
    }




int cnt=0; //this cnt variable is basically counting till it reaches the number of customers


/*
this function below is the thread function that is being called by the first teller to process the customers from the queue, it operates in parallel with teller 2 function which is called by the 2nd teller.
*/

void* teller1(void *arg)  
{
 int p;
 

 while(cnt<n)
 {
 	m.lock();
	p=a[cnt]; //reads the customer to be served from the queue in isolation so that teller2 function also does not read the same value  
	cnt++;
        m.unlock();
	
	//the customer prints his/her token in the shared array in the below function
	
	for(int i=0;i<8;i++)
	{
		w[i]=p;  
	} 	
	
	//the below function is used by the teller one to atomically output the token values from the shared array
	
	m1.lock();
	for(int i=0;i<8;i++)
	{       
	  	if(w[i]==0) //condition to exit the loop if there is no customer left to be serviced
	  	exit(0);
	  	
		cout<<w[i]<<" ";
		
   	}
	m1.unlock();
	
	
	//after processing a customer the lazy teller takes rest for 5 seconds as stated in the problem
	
	cout<<endl;
	sleep(5);
	
 }

	 	
return NULL;
}


/*
this function below is the thread function that is being called by the second teller to process the customers from the queue, it operates in parallel with teller 1 function which is called by the 1st teller.
*/


void* teller2(void *arg)
{
 int p;

 while(cnt<n)
 {
 	m.lock();
	p=a[cnt];  //reads the customer to be served from the queue in isolation so that teller1 function also does not read the same value  
	cnt++;
	m.unlock();
	
	
	//the customer prints his/her token in the shared array in the below function
	
	for(int i=8;i<16;i++)
	{
		w[i]=p;
	} 
	
	
	//the below function is used by the teller one to atomically output the token values from the shared array
	
	m1.lock();
	for(int i=8;i<16;i++)
	{
	 	if(w[i]==0)  //condition to exit the loop if there is no customer left to be serviced
	  	exit(0);
	  	
		cout<<w[i]<<" ";
		
	}
	m1.unlock();
		
	//after processing a customer the lazy teller takes rest for 5 seconds as stated in the problem
	
	
	cout<<endl;
	sleep(5);
	
 }

	 	
return NULL;
}





int main()
{
cout<<"Enter the number of customers"<<endl;
cin>>n; //n is the number of customers 

   	for(int i=0;i<n;i++)
	{
		if(i==0)
		{
		  srand(time(0)); 
		  c[i]=rand()%200+1;	//the tocken of the first customer is assigned randomly within the range of 200 
		}
		else
		{
			c[i]=c[i-1]+100;  //after that the tocken is being monotonically increased 
		}

	}
	
	
	//The below commented function is to check the tockens that are being assigned to the customers in monotonically increasing order
	
	
	/*
	function to check for the array values
	*/
	
	/* //checking token values
	
	for(int i=0;i<n;i++)
	{
		cout<<c[i]<<" ";	
	}
	
	cout<<endl;
	*/
	
	
	
	//Now what the below function does is that, it considers each and every customer as a thread and they all will race to acquire a place in the queue
	
	
	
        //Declaring n(n=number of customers) threads for random insertion in the fifo queue
	pthread_t threads[n]; 
	
	for (int i = 0; i < n; i++) 
	{ 
		 int *arg = (int*) malloc(sizeof(*arg));
		 *arg =i;
		pthread_create(&threads[i], NULL, fifo,arg); 
	}
	
	
	//joining the threads
	
	for (int i = 0; i < n; i++) 
		pthread_join(threads[i], NULL);	  
	


       /*
       the below commented function is to check how the customers have filled the queue, it will output their token numbers in order 
       they are inserted in the fifo queue
       */
	
  /*	//To check the waiting queue
	
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<" ";	
	}
	
	cout<<endl;
 	
 	*/	
 	
 	
  
         // Creating 2 Tellers as threads and they will run in parallel and process the customers from the queue
   
         pthread_t t1,t2; //t1=teller one //t2=teller two

	 pthread_create(&t1, NULL, teller1, NULL);
	 pthread_create(&t2, NULL, teller2, NULL); 
	
	
        // joining and waiting for all threads to complete  
		pthread_join(t1, NULL);
		pthread_join(t2, NULL);	 
 	
 	
}


