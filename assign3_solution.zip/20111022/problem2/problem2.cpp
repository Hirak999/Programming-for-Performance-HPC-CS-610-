// Compile: g++ -O2 -o problem2 problem2.cpp
// Execute: ./problem2

#include <cmath>
#include <iostream>
#include <sys/time.h>
#include <unistd.h>

using namespace std;

const int N = 1024;
const int Niter = 10;
const double THRESHOLD = 0.0000001;

double rtclock() {
  struct timezone Tzp;
  struct timeval Tp;
  int stat;
  stat = gettimeofday(&Tp, &Tzp);
  if (stat != 0) {
    cout << "Error return from gettimeofday: " << stat << endl;
  }
  return (Tp.tv_sec + Tp.tv_usec * 1.0e-6);
}

void reference(double** A, double** B, double** C) {
  int i, j, k;
  for (i = 0; i < N; i++) {
    for (j = 0; j < N; j++) {
      for (k = 0; k < i + 1; k++) {
        C[i][j] += A[k][i] * B[j][k];
      }
    }
  }
}

void check_result(double** w_ref, double** w_opt) {
  double maxdiff, this_diff;
  int numdiffs;
  int i, j;
  numdiffs = 0;
  maxdiff = 0;

  for (i = 0; i < N; i++) {
    for (j = 0; j < N; j++) {
      this_diff = w_ref[i][j] - w_opt[i][j];
      if (fabs(this_diff) > THRESHOLD) {
        numdiffs++;
        if (this_diff > maxdiff)
          maxdiff = this_diff;
      }
    }
  }

  if (numdiffs > 0) {
    cout << numdiffs << " Diffs found over threshold " << THRESHOLD << "; Max Diff = " << maxdiff
         << endl;
  } else {
    cout << "No differences found between base and test versions\n";
  }
}

// TODO: THIS IS INITIALLY IDENTICAL TO REFERENCE. MAKE YOUR CHANGES TO OPTIMIZE THIS FUNCTION
// You can create multiple versions of the optimized() function to test your changes

//this is optimised version by introduing a single variable





void optimized(double** A, double** B, double** C) {
  int i, j, k, u, v,BLOCK_SIZE=64;
 double sum;
 int lim = BLOCK_SIZE * (N/BLOCK_SIZE);
  
  
  
 for (u = 0; u < lim; u += BLOCK_SIZE) 
 {
 	for (v = 0; v < lim; v += BLOCK_SIZE) 
 	{
		  for (i = u; i < u+BLOCK_SIZE; i++) 
		  {
			    for (j = v; j < v + BLOCK_SIZE; j++) 
			    {
			    
				      sum = C[i][j];
				      
				      for (k = 0; k < i+1; k++) 
				      {
					sum += A[k][i] * B[j][k];
				       }
			       
			       C[i][j]=sum;
                             }
                    }
          }
          
  }
  
}



int main() {
  double clkbegin, clkend;
  double t;

  int i, j, it;
  cout.setf(ios::fixed, ios::floatfield);
  cout.precision(5);

  double **A, **B, **C_ref, **C_opt;
  A = new double*[N];
  B = new double*[N];
  C_ref = new double*[N];
  C_opt = new double*[N];
  for (i = 0; i < N; i++) {
    A[i] = new double[N];
    B[i] = new double[N];
    C_ref[i] = new double[N];
    C_opt[i] = new double[N];
  }

  for (i = 0; i < N; i++) {
    for (j = 0; j < N; j++) {
      A[i][j] = i + j + 1;
      B[i][j] = (i + 1) * (j + 1);
      C_ref[i][j] = 0.0;
      C_opt[i][j] = 0.0;
    }
  }

  clkbegin = rtclock();
  for (it = 0; it < Niter; it++)
    reference(A, B, C_ref);
  clkend = rtclock();
  t = clkend - clkbegin;
  cout << "Reference Version: Matrix Size = " << N << ", " << 2.0 * 1e-9 * N * N * Niter / t
       << " GFLOPS; Time = " << t / Niter << " sec\n";

  clkbegin = rtclock();
  for (it = 0; it < Niter; it++)
    optimized(A, B, C_opt);
  clkend = rtclock();
  t = clkend - clkbegin;
  cout << "Optimized Version: Matrix Size = " << N << ", Time = " << t / Niter << " sec\n";
  check_result(C_ref, C_opt);

 

  return EXIT_SUCCESS;
}
