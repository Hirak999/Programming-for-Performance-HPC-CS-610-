

#include <cassert>
#include <chrono>
#include <iostream>
#include <tbb/tbb.h>
#include <tbb/blocked_range.h>
#include <tbb/parallel_reduce.h>
using namespace tbb;
using std::cout;
using std::endl;
using std::chrono::duration_cast;
using HR = std::chrono::high_resolution_clock;
using HRTimer = HR::time_point;
using std::chrono::microseconds;

#define N (1 << 26)



uint32_t serial_find_max(const uint32_t* a) {
  uint32_t value_of_max = 0;
  uint32_t index_of_max = -1;
  for (uint32_t i = 0; i < N; i++) {
    uint32_t value = a[i];
    if (value > value_of_max) {
      value_of_max = value;
      index_of_max = i;
    }
  }
  return index_of_max;
}



class MaxCalc {    

	
private:
	const uint32_t *p;

public:      
     uint32_t max;
     uint32_t index;
     MaxCalc(const uint32_t *arr) : p(arr), max(0), index(-1)   {}
     void operator()(const blocked_range<size_t>&r) {
     const uint32_t *a = p;
     size_t end = r.end();
     for (size_t i = r.begin(); i != end; ++i) {
     uint32_t value = a[i];
        if (value > max) {
          max = value;
          index = i;
    }
  }
 }
 MaxCalc( MaxCalc &x, split ) :
 p(x.p),
 max(0),        
 index(-1) 
 {}
 
 void join( const MaxCalc &y ) 
 {   
          max = y.max;   
          index = y.max; 
          
          
  }
     
};



uint32_t tbb_find_max(const uint32_t* a) {
  
  MaxCalc fmb(a);
  parallel_reduce(blocked_range<size_t>(0,N),fmb);  
  return fmb.index;
}

int main() {
  uint32_t* a = new uint32_t[N];
  for (uint32_t i = 0; i < N; i++) {
    a[i] = i;
  }

  HRTimer start = HR::now();
  uint64_t s_max_idx = serial_find_max(a);
  HRTimer end = HR::now();
  auto duration = duration_cast<microseconds>(end - start).count();
  cout << "Sequential max index: " << s_max_idx << " in " << duration << " us" << endl;

  start = HR::now();
  uint64_t tbb_max_idx = tbb_find_max(a);
  end = HR::now();
  assert(s_max_idx == tbb_max_idx);
  duration = duration_cast<microseconds>(end - start).count();
  cout << "Parallel (TBB) max index: " << tbb_max_idx << " in " << duration << " us" << endl;

  return EXIT_SUCCESS;
}
