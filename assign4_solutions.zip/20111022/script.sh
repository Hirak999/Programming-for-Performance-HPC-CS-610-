#/bin/bash

rm -rf tbb v2020.3.zip oneTBB-2020*
wget https://github.com/oneapi-src/oneTBB/archive/v2020.3.zip
unzip v2020.3.zip
cd oneTBB-2020.3
make -j16 extra_inc=big_iron.inc
mkdir '../tbb' '../tbb/include' '../tbb/lib'
cp build/linux_intel64*/*.a ../tbb/lib
cp -r include/* ../tbb/include
cd ..
rm -rf v2020.3.zip oneTBB-2020.3
